class Visitor:
    pass