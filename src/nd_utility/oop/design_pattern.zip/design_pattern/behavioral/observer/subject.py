class Subject:
    pass