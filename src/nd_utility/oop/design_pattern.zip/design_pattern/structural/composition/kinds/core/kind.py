class Kind:
    pass