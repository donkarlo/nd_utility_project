from nd_utility.oop.design_pattern.architectural.pipes_and_filters.filter.filter import Filter
from nd_utility.oop.design_pattern.architectural.pipes_and_filters.pipe.pipe import Pipe
from nd_utility.oop.design_pattern.architectural.pipes_and_filters.pipes_and_filters import PipesAndFilters


class TrimFilter(Filter):
    def process(self, data: object) -> object:
        if not isinstance(data, str):
            raise TypeError("TrimFilter expects a string.")

        return data.strip()


class LowercaseFilter(Filter):
    def process(self, data: object) -> object:
        if not isinstance(data, str):
            raise TypeError("LowercaseFilter expects a string.")

        return data.lower()


class ReplaceSpacesWithDashFilter(Filter):
    def process(self, data: object) -> object:
        if not isinstance(data, str):
            raise TypeError("ReplaceSpacesWithDashFilter expects a string.")

        return data.replace(" ", "-")


def main() -> None:
    pipeline = PipesAndFilters()

    source_pipe = pipeline.get_source_pipe()
    trim_to_lowercase_pipe = Pipe()
    lowercase_to_replace_pipe = Pipe()
    sink_pipe = pipeline.get_sink_pipe()

    trim_filter = TrimFilter(source_pipe, trim_to_lowercase_pipe)
    lowercase_filter = LowercaseFilter(trim_to_lowercase_pipe, lowercase_to_replace_pipe)
    replace_spaces_filter = ReplaceSpacesWithDashFilter(lowercase_to_replace_pipe, sink_pipe)

    pipeline.add_filter(trim_filter)
    pipeline.add_filter(lowercase_filter)
    pipeline.add_filter(replace_spaces_filter)
    pipeline.build()

    pipeline.write("   Hello World From Pipes And Filters   ")
    result = pipeline.run()

    print(result)


if __name__ == "__main__":
    main()
