from typing import List

from nd_utility.oop.design_pattern.architectural.pipes_and_filters.filter.filter import Filter
from nd_utility.oop.design_pattern.architectural.pipes_and_filters.pipe.pipe import Pipe


class PipesAndFilters:
    def __init__(self) -> None:
        self._filters: List[Filter] = []
        self._source_pipe = Pipe()
        self._sink_pipe = Pipe()
        self._built = False

    def add_filter(self, filter_instance: Filter) -> None:
        if self._built:
            raise RuntimeError("Cannot add a filter after the pipeline has been built.")

        self._filters.append(filter_instance)

    def write(self, data: object) -> None:
        self._source_pipe.write(data)

    def read(self) -> object:
        return self._sink_pipe.read()

    def build(self) -> None:
        if len(self._filters) == 0:
            raise RuntimeError("At least one filter is required.")

        self._built = True

    def run(self) -> object:
        if not self._built:
            raise RuntimeError("Build the pipeline before running it.")

        for current_filter in self._filters:
            current_filter.run()

        return self.read()

    def get_source_pipe(self) -> Pipe:
        return self._source_pipe

    def get_sink_pipe(self) -> Pipe:
        return self._sink_pipe
