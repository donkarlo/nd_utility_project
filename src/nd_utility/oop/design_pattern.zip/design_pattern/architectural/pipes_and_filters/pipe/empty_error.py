class EmptyError(Exception):
    pass
